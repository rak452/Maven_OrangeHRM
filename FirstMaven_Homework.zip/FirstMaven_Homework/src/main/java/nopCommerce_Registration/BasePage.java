package nopCommerce_Registration;

import org.openqa.selenium.WebDriver;

public class BasePage {

     protected static WebDriver driver;
}

package nopCommerce_Registration;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestSuite extends BaseTest
{
    @Test
    public void verfiyUserShouldBeOnHomepage()
      {
          Assert.assertEquals(getTextFromElement(By.linkText("Register")),"Register");
      }
    @Test
      public void verfiyUserShouldBeAbleToRegisterSuccessfully()
      {
        clickOnElement(By.linkText("Register"));
        entertext(By.name("FirstName"),"Raj");
        entertext(By.name("LastName"),"Patel");
        Assert.assertEquals(getTextFromElement(By.linkText("Register")),"Register");

      }
}

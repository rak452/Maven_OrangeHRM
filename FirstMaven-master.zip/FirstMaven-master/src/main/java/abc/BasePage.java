package abc;

import org.openqa.selenium.WebDriver;

/**
 * Created by E7440 on 30/06/2018.
 */
public class BasePage {

    static protected WebDriver driver;

}
